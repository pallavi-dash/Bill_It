//
//  ContentView.swift
//  Bill_It
//
//  Created by Pallavi Dash on 13/08/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import SwiftUI

struct DetailView: View {
    @Environment(\.isPresented) private var isPresented
    var body: some View {
        NavigationView {
            List {
                Text("Food")
                Text("Travel")
                }.navigationBarTitle(Text("Bill Type"))
            Button(action: dismiss) {
                Text("Cancel").color(.white)
                }.padding()
                .background(Color.blue)
                .cornerRadius(10)
        }
    }
    
    func dismiss() {
        isPresented?.value = false
    }
}

struct BillView: View {
    @Environment(\.isPresented) private var isPresented
    var bills : [BillDetails] = billAgents
    
    var body: some View {
        NavigationView {
            VStack {
                List(bills) { bill in
                    BillCell(billName: bill)
                    }.navigationBarTitle(Text("All Bills"))
                Button(action: dismiss) {
                    Text("Cancel").color(.white)
                    }
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
        }
    }
    func dismiss() {
        isPresented?.value = false
    }
}

struct ContentView : View {
    var bills : [BillDetails] = billAgents
    
    var body: some View {
        NavigationView {
            VStack {
                PresentationButton(destination: BillView()) {
                    Text("View Bills").color(.blue)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                Image("camera3")
            }
        }
    }
}

#if DEBUG
struct ContentView_Previews : PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
#endif

struct BillCell: View {
    
    let billName : BillDetails
    
    var body: some View {
        return NavigationButton(destination: BillsList(name: billName.name, date: billName.date, amount: billName.amount, type: billName.type)) {
            VStack(alignment: .leading) {
                Text(billName.name)
            }
        }
    }
}
