




import SwiftUI

struct BillDetails: Identifiable {
    
    var id = UUID()
    var name: String
    var date: String
    var amount: String
    var type: String
}

let billAgents = [
    BillDetails(name: "Swati", date: "10/08/2019", amount: "1000.00", type: "Food"),
    BillDetails(name: "Soumen", date: "11/08/2019", amount: "2000.00", type: "Travel"),
    BillDetails(name: "Sourav", date: "12/08/2019", amount: "3000.00", type: "Food"),
    BillDetails(name: "Pallavi", date: "13/08/2019", amount: "4000.00", type: "Travel"),
]
