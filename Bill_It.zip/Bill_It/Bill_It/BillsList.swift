

import SwiftUI

struct BillsList: View {
    @Environment(\.isPresented) private var isPresented
    var name: String
    var date: String
    var amount: String
    var type: String
    var body: some View {
        
        VStack {
            Text("Name: \(name)").font(.title)
            Text("Date: \(date)").font(.subheadline)
            Text("Amount: \(amount)").font(.subheadline)
            HStack {
                Text("Type: \(type)").font(.subheadline)
                PresentationButton(destination: DetailView()) {
                    Image("downArrow")
                }
            }
            Divider()
            HStack {
                Button(action: dismiss) {
                    Text("Cancel").color(.white)
                    }
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
                Button(action: {}) {
                    Text("Save").color(.white)
                    }
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }
        }.padding().navigationBarTitle(Text(name), displayMode: .inline)
    }
    func dismiss() {
        isPresented?.value = false
    }
}
